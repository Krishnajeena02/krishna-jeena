


/* =================================== Aside ================================ */
const nav = document.querySelector('.nav'),
    navList = nav.querySelectorAll('li'),
    totalNavList = navList.length,
    allSection = document.querySelectorAll('.section'),
    totalSection = allSection.length;

for (let i = 0; i < totalNavList; i++) {
    //   console.log(navList[i])
    const a = navList[i].querySelector('a');


    a.addEventListener('click', function () {

        removeBackSection();

        for (let j = 0; j < totalNavList; j++) {
            if (navList[j].querySelector('a').classList.contains('actives')) {
                // allSection[j].classList.add('back-section')
                addBackSection(j);
            }
            navList[j].querySelector('a').classList.remove('actives');
        }
        this.classList.add('actives')
        showSection(this);
        if(window.innerWidth < 1200){
            asideSectionTogglerBtn()
        }

    })

}
function removeBackSection(){
    
    for(let i = 0 ; i<totalSection; i++){
        allSection[i].classList.remove('back-section');
    }
}
function addBackSection(num){
    allSection[num].classList.add('back-section')
}
function showSection(element) {
    for (let i = 0; i < totalSection; i++) {
        allSection[i].classList.remove('actives');
    }
    const target = element.getAttribute('href').split('#')[1];
    document.querySelector('#' + target).classList.add('actives')

}
function updateNav(element){

    for(let i=0; i<totalNavList; i++){
        navList[i].querySelector('a').classList.remove('actives');
    const target = element.getAttribute('href').split('#')[1];
    if(target === navList[i].querySelector('a').getAttribute('href').split('#')[1]){
        navList[i].querySelector('a').classList.add('actives');
    }
    }
}
document.querySelector('.hire-me').addEventListener('click', function(){
    const sectionIndex = this.getAttribute('data-section-index');
    removeBackSection()
    showSection(this)
    updateNav(this)
    addBackSection(sectionIndex)
})

const navTogglerBtn = document.querySelector('.nav-toggler'),
      aside = document.querySelector('.aside');
    navTogglerBtn.addEventListener('click', ()=>{
        asideSectionTogglerBtn();
    })
    function asideSectionTogglerBtn(){
        aside.classList.toggle('open');
        navTogglerBtn.classList.toggle('open');
        for(let i=0; i<totalSection; i++){
            allSection[i].classList.toggle('open');
        }
    }


    // see more btn
    function seeMo(){
        document.getElementById('more').classList.remove('more');
        document.getElementById('seeM').classList.add('seeM')
    }
    function moreOut(){
        document.getElementById('seeM').classList.remove('seeM')
        document.getElementById('more').classList.add('more')
    }



    // email validation
    var emailFeled = document.getElementById('email-f');
    function validations(){
        if(!emailFeled.value.match(/^[A-Za-z\._\-0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)){
            emailFeled.style.color = "red";
            return false;
        }
        emailFeled.style.color = "var(--text-black-700)";
        return true;
    }